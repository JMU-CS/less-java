#!/bin/bash
java -cp generated Main
