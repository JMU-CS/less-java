#!/bin/bash

java -jar lj.jar $1
